<div class="form-group">
	<hr>
	<label class="control-label col-md-3 col-sm-3 col-xs-12"></label>
	<div class="col-md-6 col-sm-6 col-xs-12">
	  <?php if($submit_title!=''): ?>
      	<button type="submit" class="btn <?php if($submit_class==''): ?> btn-success <?php else: ?> btn-<?php echo e($submit_class); ?> <?php endif; ?> btn-sm"><?php echo $submit_title; ?></button>
      <?php endif; ?>
	</div>
</div>
</form>