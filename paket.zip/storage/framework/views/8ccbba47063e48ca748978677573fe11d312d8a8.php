var $<?php echo e($id); ?> = $('#<?php echo e($id); ?>').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?php echo e($url); ?>',
        "iDisplayLength": <?php echo e($length); ?>,
        columns: [
        <?php $__currentLoopData = $field; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         {data:'<?php echo e($f['data']); ?>' <?php if($f['name']!=''): ?>, name:"<?php echo e($f['name']); ?>" <?php endif; ?>, orderable:<?php echo e($f['order']); ?>, searchable: <?php echo e($f['search']); ?>,sClass:"<?php echo e($f['class']); ?>"},
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        <?php if($useRowClass==true): ?>
        "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
            $(nRow).addClass( aData["rowClass"] );
            return nRow;
        },
        <?php endif; ?>
         "drawCallback": function( settings ) {
            //$('.act').tooltip();
        },
        <?php if($sort!=''): ?>
            "order": [[<?php echo e($sort); ?>, "asc" ]]
        <?php endif; ?>
    });