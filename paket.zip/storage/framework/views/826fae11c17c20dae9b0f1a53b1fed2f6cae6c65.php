$('#<?php echo e($id); ?>').ajaxForm({
	beforeSubmit:function(){$("#modal-<?php echo e($id); ?>").modal('hide'); startLoading()},
	success:function($respon){
		stopLoading();
		if ($respon.status==true){
			showNotify('Berhasil',$respon.message);
			<?php if($callback!=''): ?> <?php echo e($callback); ?>(); <?php endif; ?>
		}else{
			showAlert('Gagal',$respon.message);
		}

	},
	error:function(){
		showAlert('Gagal','Terjadi Kesalahan, Periksa Koneksi Internet!');
	}
}); 