<?php
$tab1 = "&nbsp;&nbsp;&nbsp;&nbsp;";
$tab2 = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
$tab3 = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
$tab4 = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
$tab5 = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
?>

 <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
        <li role="presentation" class="active"><a href="#tab_rest_route1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Route/web.php</a>
        </li>
        <li role="presentation" class=""><a href="#tab_rest_route2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">CRUD Controller</a>
        </li>
        <li role="presentation" class=""><a href="#tab_rest_route3" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">DT Controller</a>
        </li>
        <li role="presentation" class=""><a href="#tab_rest_route4" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">Blade Template</a>
        </li>
      </ul>
      <div id="myTabContent" class="tab-content">
        <div role="tabpanel" class="tab-pane fade active in" id="tab_rest_route1" aria-labelledby="home-tab">
<h4>Copi Code ke Route/Web.php</h4>
<pre>
<code>
	/*Group Menu > Nama Menu */
	Route::group(['prefix'=>'<?php echo e($prefix); ?>'],function(){
	<?php echo e($tab1); ?>Route::get('/','<?php echo e($crud_controller); ?>@index_<?php echo e($table); ?>');
	<?php echo e($tab1); ?>Route::get('/datatable','<?php echo e($datatable_controller); ?>@datatable_<?php echo e($table); ?>');
	<?php echo e($tab1); ?>Route::get('/get/{uuid}','<?php echo e($crud_controller); ?>@get_record_<?php echo e($table); ?>');
	<?php echo e($tab1); ?>Route::post('/insert','<?php echo e($crud_controller); ?>@insert_<?php echo e($table); ?>');
	<?php echo e($tab1); ?>Route::post('/update','<?php echo e($crud_controller); ?>@update_<?php echo e($table); ?>');
	<?php echo e($tab1); ?>Route::post('/delete','<?php echo e($crud_controller); ?>@delete_<?php echo e($table); ?>');
	});
</code>
</pre>
        </div>
        <div role="tabpanel" class="tab-pane fade" id="tab_rest_route2" aria-labelledby="profile-tab">
<h4>Controller: <?php echo e($crud_controller); ?>.php</h4>
<pre>
<code>
	/*Start Code Route <?php echo e($prefix); ?>*/
	/*============================*/

	function index_<?php echo e($table); ?>(){
	<?php echo e($tab1); ?>/* tambahkan baris code jika perlu */
	<?php echo e($tab1); ?>return view('group.nama_menu',['var1'=>$var1]);
	}
	
	function get_record_<?php echo e($table); ?>($uuid){
	<?php echo e($tab1); ?>/*tambahkan baris code jika perlu*/
	<?php echo e($tab1); ?>$record = DB::table('<?php echo e($table); ?> as a')->where('a.uuid', $uuid)->first();
	<?php echo e($tab1); ?>if($record){
	<?php echo e($tab1); ?><?php echo e($tab1); ?>return response()->json($record);
	<?php echo e($tab1); ?>}else{
	<?php echo e($tab1); ?><?php echo e($tab1); ?>return -1;
	<?php echo e($tab1); ?><?php echo e('}'); ?>

	}
	
	function insert_<?php echo e($table); ?>(Request $r){
	<?php echo e($tab1); ?>$respon = array('status'=>false,'message'=>'Gagal Menambahkan Data, Data Tidak Valid!');
	<?php echo e($tab1); ?>$uuid = $this->GenUuid();
	<?php echo e($tab1); ?>$record = array(
<?php $__currentLoopData = $list_columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($d->EXTRA!='auto_increment'): ?>
	<?php echo e($tab2); ?>"<?php echo e($d->COLUMN_NAME); ?>"=>$r-><?php echo e($d->COLUMN_NAME); ?>,
<?php endif; ?>
<?php if($d->COLUMN_NAME=='created_at'): ?>
	<?php echo e($tab2); ?>"<?php echo e($d->COLUMN_NAME); ?>"=>date('Y-m-d H:i:s'),
<?php endif; ?>
<?php if($d->COLUMN_NAME=='created_by'): ?>
	<?php echo e($tab2); ?>"<?php echo e($d->COLUMN_NAME); ?>"=>Auth::user()->id,
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php echo e($tab2); ?>"uuid"=>$uuid,
	<?php echo e($tab1); ?>);
    <?php echo e($tab2); ?>/* tambahkan baris code jika perlu */
    <?php echo e($tab2); ?>if(DB::table('<?php echo e($table); ?>')->insert($record)){
    	<?php echo e($tab2); ?>$respon = array('status'=>true,'message'=>'Berhasil Menambahkan Data!');
    <?php echo e($tab2); ?><?php echo e('}'); ?>

    <?php echo e($tab2); ?>return response()->json($respon);
	}

	function update_<?php echo e($table); ?>(Request $r){
	<?php echo e($tab1); ?>$respon = array('status'=>false,'message'=>'Gagal Menyimpan Data, Data Tidak Valid!');
	<?php echo e($tab1); ?>$uuid = $r->uuid;
	<?php echo e($tab1); ?>$current = DB::table('<?php echo e($table); ?> as a')->where('a.uuid', $uuid)->first();
	<?php echo e($tab1); ?>$record = array(
<?php $__currentLoopData = $list_columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($d->EXTRA!='auto_increment'): ?>
	<?php echo e($tab2); ?>"<?php echo e($d->COLUMN_NAME); ?>"=>$r-><?php echo e($d->COLUMN_NAME); ?>,
<?php endif; ?>
<?php if($d->COLUMN_NAME=='updated_at'): ?>
	<?php echo e($tab2); ?>"<?php echo e($d->COLUMN_NAME); ?>"=>date('Y-m-d H:i:s'),
<?php endif; ?>
<?php if($d->COLUMN_NAME=='updated_by'): ?>
	<?php echo e($tab2); ?>"<?php echo e($d->COLUMN_NAME); ?>"=>Auth::user()->id,
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php echo e($tab1); ?>);
    <?php echo e($tab2); ?>/* tambahkan baris code jika perlu */
    <?php echo e($tab2); ?>if(DB::table('<?php echo e($table); ?> as a')->where('a.uuid',$r->uuid)->update($record)){
    	<?php echo e($tab2); ?>$respon = array('status'=>true,'message'=>'Update Data Berhasil Disimpan!');
    <?php echo e($tab2); ?><?php echo e('}'); ?>

    <?php echo e($tab2); ?>return response()->json($respon);
	}

	function delete_<?php echo e($table); ?>(Request $r){
	<?php echo e($tab1); ?>$uuid=$r->uuid; $record = DB::table('<?php echo e($table); ?> as a')->where('a.uuid', $r->uuid)->first();
	<?php echo e($tab1); ?>if($record){
	<?php echo e($tab2); ?>/* tambahkan baris code jika perlu */
	<?php echo e($tab1); ?><?php echo e($tab1); ?>DB::table('<?php echo e($table); ?>')->where('uuid',$uuid)->delete();
	<?php echo e($tab1); ?><?php echo e($tab1); ?>$respon = array('status'=>true,'message'=>'Data Berhasil Dihapus!');
	<?php echo e($tab1); ?>}else{
	<?php echo e($tab2); ?>$respon = array('status'=>false,'message'=>'Data Tidak Ditemukan!');
	<?php echo e($tab1); ?><?php echo e('}'); ?>

	<?php echo e($tab1); ?>return response()->json($respon);
	}

	/*============================*/
	/*End Code Route <?php echo e($prefix); ?>*/
</code>
</pre>
        </div>
        <div role="tabpanel" class="tab-pane fade" id="tab_rest_route3" aria-labelledby="profile-tab">
<h4>Controller: <?php echo e($datatable_controller); ?>.php</h4>
<pre>
<code>
	/*Datatable <?php echo e($prefix); ?> : Table=> <?php echo e($table); ?>*/
	/*============================*/
	function datatable_<?php echo e($table); ?>(){
	<?php echo e($tab1); ?>$query = DB::table('<?php echo e($table); ?> as a')->select('a.*');
	<?php echo e($tab1); ?>return Datatables::of($query)
	<?php echo e($tab2); ?>->addColumn('action', function ($query) {
    <?php echo e($tab2); ?>$edit = ""; $delete = "";
    <?php echo e($tab2); ?>if($this->auu()){
    <?php echo e($tab2); ?><?php echo e($tab1); ?>$edit = '<?php echo e('<'); ?>a href="#" class="act" data-toggle="modal" data-uuid="'.$query->uuid.'"data-target="#modal-form-edit-<?php echo e($table); ?>" title="Edit"><?php echo e('<'); ?>i class="la la-edit"><?php echo e('<'); ?>/i><?php echo e('<'); ?>/a> ';
            }
    <?php echo e($tab2); ?>if($this->aud()){
    <?php echo e($tab2); ?><?php echo e($tab1); ?>$delete = '<?php echo e('<'); ?>a href="#" data-target="#modal-form-hapus-<?php echo e($table); ?>" data-uuid="'.$query->uuid.'"  title="Hapus" data-toggle="modal" class="act"><?php echo e("<"); ?>i class="la la-trash"><?php echo e("<"); ?>/i><?php echo e("<"); ?>/a> ';
    <?php echo e($tab2); ?>}
    <?php echo e($tab2); ?><?php echo e($tab1); ?>$action =  $edit."".$delete;
    <?php echo e($tab2); ?>if ($action==""){$action='<?php echo e('<'); ?>a href="#" class="act"><?php echo e('<'); ?>i class="la la-lock"><?php echo e('<'); ?>/i><?php echo e('<'); ?>/a>'; }
    <?php echo e($tab2); ?><?php echo e($tab1); ?>return $action;
    <?php echo e($tab2); ?>})
    <?php echo e($tab2); ?>->addIndexColumn()
    <?php echo e($tab2); ?>->rawColumns(['action'])
    <?php echo e($tab2); ?>->make(true);
	}
	/*============================*/
	/*End Datatable*/
</code>
</pre>          
        </div>

        <div role="tabpanel" class="tab-pane fade" id="tab_rest_route4" aria-labelledby="profile-tab">
<h4>Template Blade</h4>
<pre>
<code>
	<?php echo e('@'); ?>extends('layout')
	<?php echo e('@'); ?>section('content')
	<?php echo e('<'); ?>?php
	loadHelper('akses');
	$base_route = '<?php echo e($prefix); ?>';
	?>
	<?php echo e('<'); ?>hr>
	<?php echo e('<'); ?>div class="row">
	<?php echo e($tab1); ?><?php echo e('<'); ?>div class="col-md-12 col-sm-12 col-xs-12 pd-20">
	<?php echo e($tab2); ?><?php echo e('<'); ?>div class="x_panel">
	<?php echo e($tab3); ?><?php echo e('<'); ?>div class="x_title">
	<?php echo e($tab4); ?><?php echo e('<'); ?>div class="pull-right"><?php echo e('<'); ?>span class="loading-panel"><?php echo e('<'); ?>/span><?php echo e('<'); ?>/div>
	<?php echo e($tab4); ?><?php echo e($tab1); ?><?php echo e('<'); ?>h2>{TITLE PAGE}<?php echo e('<'); ?>/h2>
	<?php echo e($tab4); ?><?php echo e($tab1); ?><?php echo e('<'); ?>div class="clearfix"><?php echo e('<'); ?>/div>
	<?php echo e($tab3); ?><?php echo e('<'); ?>/div>
	<?php echo e($tab3); ?><?php echo e('<'); ?>div class="x_content">
	<?php echo e($tab3); ?><?php echo e($tab1); ?><?php echo e('<'); ?>p>
	<?php echo e($tab3); ?><?php echo e($tab1); ?><?php echo e('<'); ?>!--tombol aksi disini cuy-->
	<?php echo e($tab3); ?><?php echo e($tab1); ?><?php echo e('<'); ?>/p>
	<?php echo e($tab3); ?><?php echo e($tab1); ?><?php echo e('<'); ?>hr>
	<?php echo e($tab3); ?><?php echo e($tab1); ?><?php echo e('<'); ?>div class="row">
	<?php echo e($tab3); ?><?php echo e($tab1); ?><?php echo e($tab1); ?><?php echo e('<'); ?>div class="col-md-12">
	<?php echo e($tab3); ?><?php echo e($tab1); ?><?php echo e($tab1); ?><?php echo e('<'); ?>!--Kopikan disini cuy-->
	<?php echo e($tab3); ?><?php echo e($tab1); ?><?php echo e($tab1); ?><?php echo e('<'); ?>/div>			        
	<?php echo e($tab3); ?><?php echo e($tab1); ?><?php echo e('<'); ?>/div>				
	<?php echo e($tab3); ?><?php echo e('<'); ?>/div>
	<?php echo e($tab2); ?><?php echo e('<'); ?>/div>
	<?php echo e($tab1); ?><?php echo e('<'); ?>/div>
	<?php echo e('<'); ?>/div>
	<?php echo e('@'); ?>endsection

	<?php echo e('@'); ?>section("modal")
		<?php echo e('<'); ?>!--Kopikan disini cuy-->
	<?php echo e('@'); ?>endsection


	<?php echo e('@'); ?>section('js')
	<?php echo e('<'); ?>script type="text/javascript">
		$(function(){
			//Kopikan disini cuy
		})
	<?php echo e('<'); ?>/script>
	<?php echo e('@'); ?>endsection
</code>
</pre>     
        </div>
      </div>
