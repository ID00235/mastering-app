<?php
$tab1 = "&nbsp;&nbsp;&nbsp;&nbsp;";
$tab2 = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
$tab3 = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
$tab4 = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
$tab5 = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
?>
<?php 
$n= 0;
$model = array();
//array('none','textfield','textarea','radio','selected','readonly','hidden');
foreach ($field as $f) {
	if ($jenis[$n]=='textfield'){
		array_push($model,["name"=>$f ,"jenis"=>'textfield']);
	}
	if ($jenis[$n]=='textarea'){
		array_push($model,["name"=>$f ,"jenis"=>'textarea']);
	}
	if ($jenis[$n]=='radio'){
		array_push($model,["name"=>$f ,"jenis"=>'radio']);
	}
	if ($jenis[$n]=='selected'){
		array_push($model,["name"=>$f ,"jenis"=>'selected']);
	}
	if ($jenis[$n]=='readonly'){
		array_push($model,["name"=>$f ,"jenis"=>'readonly']);
	}
	if ($jenis[$n]=='hidden'){
		array_push($model,["name"=>$f ,"jenis"=>'hidden']);
	}
	$n++;
}
?>
 <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
 		<li role="presentation" class="active"><a href="#tab_gen_form_create0" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Tombol [Tambah]</a>
        </li>
        <li role="presentation" class="active"><a href="#tab_gen_form_create1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true"><?php echo e('@'); ?>section('modal')</a>
        </li>
        <li role="presentation" class=""><a href="#tab_gen_form_create2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false"><?php echo e('@'); ?>section('js')</a>
        </li>
      </ul>
      <div id="myTabContent" class="tab-content">
      	<div role="tabpanel" class="tab-pane fade active in" id="tab_gen_form_create0" aria-labelledby="home-tab">
<pre>
<code>
	<?php echo e("@"); ?>if(ucc())
	<?php echo e("{"); ?><?php echo e("{"); ?>Html::bsLinkModal('tambah-<?php echo e($table); ?>','modal-form-tambah-<?php echo e($table); ?>','<?php echo e("<"); ?>i class="la la-plus"><?php echo e("<"); ?>/i>','primary')<?php echo e("}"); ?><?php echo e("}"); ?>

	<?php echo e("@"); ?>endif
</code>
</pre>
      	</div>
        <div role="tabpanel" class="tab-pane" id="tab_gen_form_create1" aria-labelledby="home-tab">
<pre>
<code>
	<?php echo e("@"); ?>if(ucc())
	<?php echo e("{"); ?><?php echo e("{"); ?>Html::bsFormModalOpen('form-tambah-<?php echo e($table); ?>','Tambah Data','<?php echo e($action); ?>') <?php echo e("}"); ?><?php echo e("}"); ?>

<?php foreach($model as $m) {$name = $m['name']; $element = $m['jenis']; ?>
<?php if($element=='textfield'): ?>
	<?php echo e($tab1); ?><?php echo e("{"); ?><?php echo e("{"); ?> Form::bsText('<?php echo e($name); ?>','<?php echo e($name); ?>','',true,'') <?php echo e("}"); ?><?php echo e("}"); ?>

<?php endif; ?>
<?php if($element=='textarea'): ?>
	<?php echo e($tab1); ?><?php echo e("{"); ?><?php echo e("{"); ?> Form::bsTextarea('<?php echo e($name); ?>','<?php echo e($name); ?>','',true,'') <?php echo e("}"); ?><?php echo e("}"); ?>

<?php endif; ?>
<?php if($element=='selected'): ?>
	<?php echo e($tab1); ?><?php echo e("{"); ?><?php echo e("{"); ?> Form::bsSelect('<?php echo e($name); ?>','<?php echo e($name); ?>',$list_<?php echo e($name); ?>,true,'select2') <?php echo e("}"); ?><?php echo e("}"); ?>

<?php endif; ?>
<?php if($element=='radio'): ?>
	<?php echo e($tab1); ?><?php echo e("{"); ?><?php echo e("{"); ?> Form::bsRadionInline('<?php echo e($name); ?>','<?php echo e($name); ?>',$option_<?php echo e($name); ?>,true) <?php echo e("}"); ?><?php echo e("}"); ?>

<?php endif; ?>
<?php if($element=='hidden'): ?>
	<?php echo e($tab1); ?><?php echo e("{"); ?><?php echo e("{"); ?> Form::bsHidden('<?php echo e($name); ?>') <?php echo e("}"); ?><?php echo e("}"); ?>

<?php endif; ?>
<?php if($element=='readonly'): ?>
	<?php echo e($tab1); ?><?php echo e("{"); ?><?php echo e("{"); ?> Form::bsReadonly('<?php echo e($name); ?>','<?php echo e($name); ?>') <?php echo e("}"); ?><?php echo e("}"); ?>

<?php endif; ?>
<?php } ?>
	<?php echo e($tab1); ?><?php echo e("{{"); ?>Html::bsFormModalClose('Simpan','success') <?php echo e("}"); ?><?php echo e("}"); ?>

	<?php echo e("@"); ?>endif
</code>
</pre>
        </div>
        <div role="tabpanel" class="tab-pane fade" id="tab_gen_form_create2" aria-labelledby="profile-tab">
<pre>
<code>
	 $validator_tambah_<?php echo e($table); ?> = $("#form-tambah-<?php echo e($table); ?>").validate();
	 <?php echo e("{"); ?><?php echo e("{"); ?>Html::jsModalShow('modal-form-tambah-<?php echo e($table); ?>') <?php echo e("}"); ?><?php echo e("}"); ?>

		$validator_tambah_<?php echo e($table); ?>.resetForm();
		$("#form-tambah-<?php echo e($table); ?>").clearForm();
<?php foreach($model as $m) {$name = $m['name']; $element = $m['jenis']; ?>
<?php if($element=='selected'): ?>
		<?php echo e("{"); ?><?php echo e("{"); ?>Html::jsClearForm('form-tambah-<?php echo e($table); ?>','select','<?php echo e($name); ?>') <?php echo e("}"); ?><?php echo e("}"); ?>

<?php endif; ?>
<?php } ?>
	<?php echo e("{"); ?><?php echo e("{"); ?>Html::jsClose() <?php echo e("}"); ?><?php echo e("}"); ?>

	<br>
	var callback_submit_tambah_<?php echo e($table); ?> = function(){$tabel1.ajax.reload(null, true);}
	<?php echo e("{"); ?><?php echo e("{"); ?> Html::jsSubmitFormModal('form-tambah-<?php echo e($table); ?>','callback_submit_tambah_<?php echo e($table); ?>') <?php echo e("}"); ?><?php echo e("}"); ?>

</code>
</pre>
        </div>
        
      </div>
