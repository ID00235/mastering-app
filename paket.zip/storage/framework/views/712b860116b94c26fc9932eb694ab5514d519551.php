<table class="table <?php if($model==''): ?>table-striped <?php endif; ?> <?php if($model=='non-striped'): ?> <?php endif; ?> <?php if($model=='bordered'): ?> table-bordered <?php endif; ?> table-condensed table-hover" id="<?php echo e($id); ?>">
    <thead>
      <tr>
      	<?php $__currentLoopData = $field; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <th <?php if($f['width']!=''): ?>width="<?php echo e($f['width']); ?>;"<?php endif; ?>><center><?php echo e($f['name']); ?></center></th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tr>
    </thead>
	<tbody></tbody>
</table>