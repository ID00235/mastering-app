<form class="form-horizontal form-label-left" 
id="<?php echo e($id); ?>" method="post" enctype="multipart/form-data" action="<?php echo e(url($url)); ?>">
<?php echo e(csrf_field()); ?>