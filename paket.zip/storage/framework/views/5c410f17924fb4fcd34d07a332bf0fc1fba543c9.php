<?php echo e(Form::bsText('action','Route to Action','',true,'')); ?>

<?php
$list_elemen = array('none','textfield','textarea','radio','selected','readonly','hidden');
$array = [];
foreach ($list_elemen as $d){
	array_push($array, ['value'=>$d,'text'=>$d]);
}
$list_elemen = json_decode(json_encode($array));
?>
<hr>
<?php $__currentLoopData = $field; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e(Form::bsText('field[]','Kolom',$k->COLUMN_NAME,true,'')); ?>

<?php echo e(Form::bsSelect('jenis[]','Jenis Komponen',$list_elemen,true,'select2')); ?>

<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>