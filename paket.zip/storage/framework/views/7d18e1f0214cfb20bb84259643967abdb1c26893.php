	<?php $__env->startSection('content'); ?>
	<?php
	loadHelper('akses');
	$base_route = 'ref-program';
	?>
	<hr>
	<div class="row">
	    <div class="col-md-12 col-sm-12 col-xs-12 pd-20">
	        <div class="x_panel">
	            <div class="x_title">
	                <div class="pull-right"><span class="loading-panel"></span></div>
	                    <h2>Daftar Program</h2>
	                    <div class="clearfix"></div>
	            </div>
	            <div class="x_content">
	                <p>
	                <!--tombol aksi disini cuy-->
	                <?php if(ucc()): ?>
					<?php echo e(Html::bsLinkModal('tambah-program','modal-form-tambah-program','<i class="la la-plus"></i> Tambah','primary')); ?>

					<?php endif; ?>
	                </p>
	                <hr>
	                <div class="row">
	                    <div class="col-md-12">
	                    <!--Kopikan disini cuy-->
	                    <?php 
			         	$kolom = array(
			         				['name'=>'No.','width'=>'30px'],
			         				['name'=>'Kode Program','width'=>'80px'],
			         				['name'=>'Nama Program','width'=>''],
			         				['name'=>'Jml Kegiatan','width'=>''],
			         				['name'=>'Action','width'=>'50px'],
			         			);
			         	?>
		         		<?php echo e(Html::bsDatatable('tabel1',$kolom,'non-striped')); ?>

	                    </div>			        
	                </div>				
	            </div>
	        </div>
	    </div>
	</div>
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection("modal"); ?>
		<!--Kopikan disini cuy-->

	<?php if(ucc()): ?>
		<?php echo e(Html::bsFormModalOpenLg('form-tambah-program','Tambah Data','ref-program/insert')); ?>

		    <?php echo e(Form::bsSelect('id_urusan','Urusan',$list_id_urusan,true,'select2')); ?>

		    <?php echo e(Form::bsText('kode_program','Kode Program','',true,'')); ?>

		    <?php echo e(Form::bsText('nama_program','Nama Program','',true,'')); ?>

	    <?php echo e(Html::bsFormModalClose('Simpan','success')); ?>

	<?php endif; ?>

	<?php $__env->stopSection(); ?>


	<?php $__env->startSection('js'); ?>
	<script type="text/javascript">
		$(function(){
			//Kopikan disini cuy

			<?php 
			$field = array(
					['name'=>'','data'=>'DT_Row_Index','order'=>'false', 'search'=>'false','class'=>'text-center'],
					['name'=>'kode','data'=>'kode','order'=>'true', 'search'=>'true','class'=>''],
					['name'=>'nama','data'=>'nama','order'=>'false', 'search'=>'true','class'=>''],
					['name'=>'n_kegiatan','data'=>'n_kegiatan','order'=>'false', 'search'=>'false','class'=>'text-center'],
					['name'=>'','data'=>'action','order'=>'false', 'search'=>'false','class'=>'text-center'],
				);
			?>
			<?php echo e(Html::jsDatatable('tabel1',$field,url('ref-program/datatable'),25,1,true)); ?>


			$validator_tambah_program = $("#form-tambah-program").validate();
			 	<?php echo e(Html::jsModalShow('modal-form-tambah-program')); ?>

					$validator_tambah_program.resetForm();
					$("#form-tambah-program").clearForm();
				<?php echo e(Html::jsClearForm('form-tambah-program','select','id_urusan')); ?>

			<?php echo e(Html::jsClose()); ?>

			

			$("#form-tambah-program select[name=id_urusan]").on('change', function(){
				$id_urusan = $(this).val();
				$.get("<?php echo e(url($base_route.'/gen-kode-program')); ?>" + '/' + $id_urusan, function($data){
					<?php echo e(Html::jsValueForm('form-tambah-program','input','kode_program')); ?>

				});
			})

			var callback_submit_tambah_program = function(){$tabel1.ajax.reload(null, true);}
			<?php echo e(Html::jsSubmitFormModal('form-tambah-program','callback_submit_tambah_program')); ?>

		})
	</script>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>