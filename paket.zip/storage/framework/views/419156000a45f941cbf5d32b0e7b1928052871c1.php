	  </div>
	  </div>
      <div class="modal-footer">
      	<?php if($submit_title!=''): ?>
      	<button type="submit" class="btn <?php if($submit_class==''): ?> btn-success <?php else: ?> btn-<?php echo e($submit_class); ?> <?php endif; ?> btn-sm"><?php echo $submit_title; ?></button>
      	<?php endif; ?>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
</form>