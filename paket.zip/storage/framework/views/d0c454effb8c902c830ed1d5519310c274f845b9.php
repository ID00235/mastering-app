<div class="form-group">
	<label class="control-label col-md-3 col-sm-3 col-xs-12" 
	for="<?php echo e($fieldname); ?>"><?php echo e($label); ?>

	</label>
	<div class="col-md-8 col-sm-8 col-xs-12">
	  <input class="form-control col-md-7 col-xs-12" id="<?php echo e($fieldname); ?>" name="<?php echo e($fieldname); ?>" readonly="readonly" 
	  type="text" value="<?php echo e($value); ?>">
	</div>
</div>