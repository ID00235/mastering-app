<?php
$path = Request::segment(1);

$menu_session  = Session::get('menu_session');
$menu_session = json_decode($menu_session);

?>
<div class="navbar nav_title" style="border: 0;">
  <a href="<?php echo e(url('beranda')); ?>" class="site_title">
    <i class="fa fa-paw"></i> <span>E-Planning Batanghari</span></a>
</div>

<div class="clearfix"></div>
<!-- menu profile quick info -->
<div class="profile clearfix">
  
  <div class="profile_info">
    <img  style="padding-top: -5px;" src="<?php echo e(url('img/batanghari.png')); ?>" height="60" class="pull-right">
    <div style="padding-top: 15px !important">
      <span><b style="color:#fff; padding-top: 15px !important;"><i class="la la-user"></i> <?php echo e(Auth::user()->username); ?></b></span>
      <h2>Administrator</h2>
    </div>
  </div>
</div>
<!-- /menu profile quick info -->
<br />
<!-- sidebar menu -->
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
  <div class="menu_section">
    <h3>Menu</h3>
    <ul class="nav side-menu">
      <li class="<?php if($path=='beranda'): ?> active current-page <?php endif; ?>"><a href="<?php echo e(url('beranda')); ?>" ><i class="fa fa-home"></i> Beranda</a></li>
      <?php $__currentLoopData = $menu_session; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mnu_induk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li id="mnu_g_<?php echo e($mnu_induk->id_menu); ?>">
          <a href="#"><i class="<?php echo e($mnu_induk->icon); ?>"></i> <?php echo e($mnu_induk->nama_menu); ?> <span class="fa fa-chevron-down"></span></a>
          <ul class="nav child_menu" id="mnu_gc_<?php echo e($mnu_induk->id_menu); ?>">
            <?php $__currentLoopData = $mnu_induk->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mnu_child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="<?php if($path==$mnu_child->url): ?> active current-page <?php endif; ?>" id="mnu_c_<?php echo e($mnu_child->id_menu); ?>">
              <a href="<?php echo e(url($mnu_child->url)); ?>"><?php echo e($mnu_child->nama_menu); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>

        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
</div>
<!-- /sidebar menu -->
<!-- /menu footer buttons -->
<div class="sidebar-footer hidden-small">
  <a data-toggle="tooltip" data-placement="top" title="Settings">
    <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
  </a>
  <a data-toggle="tooltip" data-placement="top" title="FullScreen">
    <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
  </a>
  <a data-toggle="tooltip" data-placement="top" title="Lock">
    <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
  </a>
  <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.html">
    <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
  </a>
</div>

<script type="text/javascript">
  var $curent_url="<?php echo e(url($path)); ?>";
</script>