<div class="form-group">
	<label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo e($label); ?> <?php if($required==true): ?><span class="required">*</span><?php endif; ?>
	</label>
	<div class="col-md-8 col-sm-8 col-xs-12">
	  <input class="form-control col-md-9 col-xs-12 <?php echo e($class); ?>" id="<?php echo e($fieldname); ?>" name="<?php echo e($fieldname); ?>" 
	  <?php if($required==true): ?> required="required" <?php endif; ?> value="<?php echo e($value); ?>" 
	  type="text">
	</div>
</div>