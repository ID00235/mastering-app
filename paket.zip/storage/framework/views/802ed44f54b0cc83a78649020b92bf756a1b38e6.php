<?php $__env->startSection('content'); ?>
<?php
loadHelper('akses');
$list_menu_induk = DB::table('menu')->select('id_menu as value','nama_menu as text')->where('id_menu_induk',0)->get();
?>
<hr>
<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12 pd-20">
	    <div class="x_panel">
		      <div class="x_title">
		      	<div class="pull-right"><span class="loading-panel"></span></div>
		        <h2>Pengaturan Menu</h2>
		        <div class="clearfix"></div>
		      </div>
		      <div class="x_content">
		        <p>
		        	<?php if(ucc()): ?>
		        	<?php echo e(Html::bsLinkModal('tambah-menu','modal-form-tambah-menu','<i class="la la-plus"></i> Menu Baru','primary')); ?>

		        	<?php endif; ?>
		        </p>
		        <hr>
		        <div class="row">
			         <div class="col-md-12">
			         	<?php 
			         	$kolom = array(
			         				['name'=>'No.','width'=>'30px'],
			         				['name'=>'Group Menu','width'=>''],
			         				['name'=>'Nama Menu','width'=>''],
			         				['name'=>'Urutan','width'=>''],
			         				['name'=>'URL','width'=>''],
			         				['name'=>'Action','width'=>'50px'],
			         			);
			         	?>
		         		<?php echo e(Html::bsDatatable('tabel1',$kolom)); ?>

			         </div>
			        
		        </div>				
		      </div>
	    </div>
	  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("modal"); ?>
<?php if(ucc()): ?>
<?php echo e(Html::bsFormModalOpen('form-tambah-menu','Tambah','setting-menu/insert')); ?>

	<?php echo e(Form::bsSelect('id_menu_induk','Group Menu',$list_menu_induk,true,'select2')); ?>

	<?php echo e(Form::bsText('urutan','Nomor Urutan','',true,'')); ?>

	<?php echo e(Form::bsText('nama_menu','Nama Menu','',true,'')); ?>

	<?php echo e(Form::bsText('url','URL Menu','',true,'')); ?>

<?php echo e(Html::bsFormModalClose('<i class="la la-save"></i> Simpan','success')); ?>

<?php endif; ?>

<?php if(ucu()): ?>
<?php echo e(Html::bsFormModalOpen('form-edit-menu','Edit','setting-menu/update')); ?>

	<?php echo e(Form::bsHidden('uuid')); ?>

	<?php echo e(Form::bsSelect('id_menu_induk','Group Menu',$list_menu_induk,true,'select2')); ?>

	<?php echo e(Form::bsText('urutan','Nomor Urut','',true,'')); ?>

	<?php echo e(Form::bsText('nama_menu','Nama Menu','',true,'')); ?>

	<?php echo e(Form::bsText('url','URL Menu','',true,'')); ?>

<?php echo e(Html::bsFormModalClose('<i class="la la-save"></i> Simpan','success')); ?>

<?php endif; ?>

<?php if(ucd()): ?>
<?php echo e(Html::bsFormModalOpen('form-hapus-menu','Anda Yakin Ingin Menghapus Data Berikut?','setting-menu/delete')); ?>

	<?php echo e(Form::bsHidden('uuid')); ?>

	<?php echo e(Form::bsReadonly('nama_menu','Nama Menu')); ?>

<?php echo e(Html::bsFormModalClose('<i class="la la-trash"></i> Hapus','warning')); ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script type="text/javascript">
$(function(){
//START JAVASCRIPT

$validator_tambah = $("#form-tambah-menu").validate();
$validator_edit = $("#form-edit-menu").validate();


<?php 
$field = array(
		['name'=>'','data'=>'DT_Row_Index','order'=>'false', 'search'=>'false','class'=>'text-center'],
		['name'=>'b.nama_menu','data'=>'group_menu','order'=>'true', 'search'=>'true','class'=>''],
		['name'=>'a.nama_menu','data'=>'nama_menu','order'=>'true', 'search'=>'true','class'=>''],
		['name'=>'a.urutan','data'=>'urutan','order'=>'false', 'search'=>'false','class'=>'text-center'],
		['name'=>'a.url','data'=>'url','order'=>'true', 'search'=>'true','class'=>''],
		['name'=>'','data'=>'action','order'=>'false', 'search'=>'false','class'=>'text-center'],
	);
?>
<?php echo e(Html::jsDatatable('tabel1',$field,url('setting-menu/data'),25)); ?>


<?php echo e(Html::jsModalShow('modal-form-tambah-menu')); ?>

	$validator_tambah.resetForm();
	$("#form-tambah-menu").clearForm();
	<?php echo e(Html::jsClearForm('form-tambah-menu','select','id_menu_induk')); ?>

<?php echo e(Html::jsClose()); ?>



<?php echo e(Html::jsModalShow('modal-form-edit-menu')); ?>

	$validator_edit.resetForm();
	$("#form-edit-menu").clearForm();
	<?php echo e(Html::jsClearForm('form-edit-menu','select','id_menu_induk')); ?>

	$uuid  = $(e.relatedTarget).data('uuid');
	$.get("<?php echo e(url('setting-menu/get')); ?>/"+$uuid, function($data){
		<?php echo e(Html::jsValueForm('form-edit-menu','input','urutan')); ?>

		<?php echo e(Html::jsValueForm('form-edit-menu','input','nama_menu')); ?>

		<?php echo e(Html::jsValueForm('form-edit-menu','input','url')); ?>

		<?php echo e(Html::jsValueForm('form-edit-menu','select','id_menu_induk')); ?>

		<?php echo e(Html::jsValueForm('form-edit-menu','input','uuid')); ?>

	});
<?php echo e(Html::jsClose()); ?>


<?php echo e(Html::jsModalShow('modal-form-hapus-menu')); ?>

	$("#form-hapus-menu").clearForm();
	$uuid  = $(e.relatedTarget).data('uuid');
	$.get("<?php echo e(url('setting-menu/get')); ?>/"+$uuid, function($data){
		<?php echo e(Html::jsValueForm('form-hapus-menu','input','nama_menu')); ?>

		<?php echo e(Html::jsValueForm('form-hapus-menu','input','uuid')); ?>

	});
<?php echo e(Html::jsClose()); ?>


var callback_submit_tambah = function(){$tabel1.ajax.reload(null, true);}
<?php echo e(Html::jsSubmitFormModal('form-tambah-menu','callback_submit_tambah')); ?>


var callback_submit_update = function(){$tabel1.ajax.reload(null, false);}
<?php echo e(Html::jsSubmitFormModal('form-edit-menu','callback_submit_update')); ?>


var callback_submit_delete = function(){$tabel1.ajax.reload(null, false);}
<?php echo e(Html::jsSubmitFormModal('form-hapus-menu','callback_submit_delete')); ?>



//END JAVASCRIPT
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>