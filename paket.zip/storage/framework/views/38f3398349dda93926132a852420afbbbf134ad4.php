<div class="form-group">
	<label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo e($label); ?> <?php if($required==true): ?><span class="required">*</span><?php endif; ?>
	</label>
	<div class="col-md-8 col-sm-8 col-xs-12">
	  <select class="form-control col-md-10 col-xs-12 <?php echo e($class); ?>" name="<?php echo e($fieldname); ?>" id="<?php echo e($fieldname); ?>" <?php if($required==true): ?> required="required" <?php endif; ?>>
	  		<option value="">[Pilihan]</option>
	  	<?php if($data): ?>
	  	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  		<option value="<?php echo e($d->value); ?>"><?php echo e($d->text); ?></option>
	  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  	<?php endif; ?>
	  </select>
	</div>
</div>