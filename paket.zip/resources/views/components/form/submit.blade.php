<div class="form-group">
	<label class="control-label col-md-3 col-sm-3 col-xs-12"></label>
	<div class="col-md-6 col-sm-6 col-xs-12">
	  <button type="submit" class="btn btn-primary btn-sm"><i class="la la-save"></i> Simpan</button>
	</div>
</div>