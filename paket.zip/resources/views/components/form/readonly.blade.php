<div class="form-group">
	<label class="control-label col-md-3 col-sm-3 col-xs-12" 
	for="{{$fieldname}}">{{$label}}
	</label>
	<div class="col-md-8 col-sm-8 col-xs-12">
	  <input class="form-control col-md-7 col-xs-12" id="{{$fieldname}}" name="{{$fieldname}}" readonly="readonly" 
	  type="text" value="{{$value}}">
	</div>
</div>